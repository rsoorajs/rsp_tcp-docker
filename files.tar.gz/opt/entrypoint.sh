#!/bin/bash
/usr/local/bin/sdrplay_apiService &
rsp_tcp -a 0.0.0.0 -p 1234
